<center>
  <img src="website.png">
  <br>
  <h3>Discord Bot Website</h3>
  <p>It is a responsive landing page for discord servers. Now, people can visit your website to see your server information.</p><br>
</center>

## Modification
Replace `\discord` to `your discord server invite link`
